--
-- ER/Studio Data Architect 8.5 SQL Code Generation
-- Company :      itri
-- Project :      TARSAN.dm1
-- Author :       c
--
-- Date Created : Thursday, July 16, 2015 15:12:22
-- Target DBMS : PostgreSQL 8.0
--

-- 
-- TABLE: ad 
--

CREATE TABLE ad(
    ad_id                BIGSERIAL,
    keywords             varchar(50),
    url                  varchar(256),
    img                  varchar(256),
    shown_times          int4            DEFAULT 0 NOT NULL,
    clicked_times        int4            DEFAULT 0 NOT NULL,
    weight               float4          NOT NULL,
    expire_date_time     timestamp,
    created_date_time    timestamp       NOT NULL,
    is_expired           boolean         NOT NULL,
    is_deleted           boolean         NOT NULL,
    CONSTRAINT "PK2" PRIMARY KEY (ad_id)
)
;



-- 
-- TABLE: ad2user 
--

CREATE TABLE ad2user(
    ad2user_id           BIGSERIAL,
    ad_id                int8         NOT NULL,
    users_id             int8         NOT NULL,
    is_clicked           boolean      NOT NULL,
    created_date_time    timestamp    NOT NULL,
    CONSTRAINT "PK4" PRIMARY KEY (ad2user_id)
)
;



-- 
-- TABLE: pattern 
--

CREATE TABLE pattern(
    pattern_id           BIGSERIAL,
    url_host             varchar(50)    NOT NULL,
    url_path             varchar(50),
    type                 int4           NOT NULL,
    signature            varchar(50)    NOT NULL,
    created_date_time    timestamp      NOT NULL,
    is_expired           boolean        NOT NULL,
    is_deleted           boolean        NOT NULL,
    is_ec_web            boolean,
    CONSTRAINT "PK6" PRIMARY KEY (pattern_id)
)
;



-- 
-- TABLE: pattern2ad 
--

CREATE TABLE pattern2ad(
    pattern2ad_id    BIGSERIAL,
    pattern_id       int8    NOT NULL,
    ad_id            int8    NOT NULL,
    CONSTRAINT "PK5" PRIMARY KEY (pattern2ad_id)
)
;



-- 
-- TABLE: user_event 
--

CREATE TABLE user_event(
    userevent_id         BIGSERIAL,
    created_date_time    timestamp      NOT NULL,
    url_host             varchar(50),
    url_path             varchar(50),
    users_id             int8           NOT NULL,
    pattern_id           int8           NOT NULL,
    CONSTRAINT "PK7" PRIMARY KEY (userevent_id)
)
;



-- 
-- TABLE: users 
--

CREATE TABLE users(
    users_id                 BIGSERIAL,
    account                  varchar(128)    NOT NULL,
    password                 varchar(128)    NOT NULL,
    is_deleted               boolean         NOT NULL,
    last_active_date_time    timestamp,
    created_date_time        timestamp       NOT NULL,
    CONSTRAINT "PK1" PRIMARY KEY (users_id)
)
;



-- 
-- TABLE: ad2user 
--

ALTER TABLE ad2user ADD CONSTRAINT "Refad2" 
    FOREIGN KEY (ad_id)
    REFERENCES ad(ad_id)
;

ALTER TABLE ad2user ADD CONSTRAINT "Refusers3" 
    FOREIGN KEY (users_id)
    REFERENCES users(users_id)
;


-- 
-- TABLE: pattern2ad 
--

ALTER TABLE pattern2ad ADD CONSTRAINT "Refpattern4" 
    FOREIGN KEY (pattern_id)
    REFERENCES pattern(pattern_id)
;

ALTER TABLE pattern2ad ADD CONSTRAINT "Refad5" 
    FOREIGN KEY (ad_id)
    REFERENCES ad(ad_id)
;


-- 
-- TABLE: user_event 
--

ALTER TABLE user_event ADD CONSTRAINT "Refusers6" 
    FOREIGN KEY (users_id)
    REFERENCES users(users_id)
;

ALTER TABLE user_event ADD CONSTRAINT "Refpattern7" 
    FOREIGN KEY (pattern_id)
    REFERENCES pattern(pattern_id)
;


